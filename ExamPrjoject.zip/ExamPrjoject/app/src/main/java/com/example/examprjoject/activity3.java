package com.example.examprjoject;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class activity3 extends AppCompatActivity {

    Button plus, plus1, minus, minus1, checkout, checkout1;
    TextView price1, price2;
    EditText edittext1, edittext2;
    int count = 0;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity3);

        plus = findViewById(R.id.plus1);
        plus1 = findViewById(R.id.plus2);
        minus = findViewById(R.id.minus1);
        minus1 = findViewById(R.id.minus2);
        checkout = findViewById(R.id.checkout1);
        checkout1 = findViewById(R.id.checkout2);
        price1 = findViewById(R.id.price1);
        price2 = findViewById(R.id.price2);
        edittext1 = findViewById(R.id.edittext1);
        edittext2 = findViewById(R.id.edittext2);

        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                count++;
                edittext1.setText(" " +count);

            }
        });

        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(count<=0) count = 0;
                       else
                count--;
                edittext1.setText(" " +count);
            }
        });




        plus1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                count++;
                edittext2.setText(" " +count);

            }
        });

        minus1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(count<=0) count = 0;
                else
                    count--;
                edittext2.setText(" " +count);
            }
        });


    }
}